// ==UserScript==
// @name         X TL Milliseconds Timestamp (現在のフォーカスツイートのみ・日本語フル形式)
// @namespace    http://tampermonkey.net/
// @version      0.5
// @description  ツイート詳細ページで、現在フォーカスされている（親/メイン）ツイートのタイムスタンプだけをミリ秒付き日本語フル形式に。リプライは変更せず、ページ遷移後も重複処理を防ぐ
// @author       Grok
// @match        https://x.com/*
// @match        https://twitter.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const twitterEpoch = 1288834974657;
    const weekdays = ['日', '月', '火', '水', '木', '金', '土'];

    let currentStatusId = null;          // 現在処理中の status ID を記憶
    let processedMainTweet = false;      // このページで親ツイートを処理済みか

    function formatFullJapaneseDate(date) {
        const y  = date.getFullYear();
        const m  = String(date.getMonth() + 1).padStart(2, '0');
        const d  = String(date.getDate()).padStart(2, '0');
        const w  = weekdays[date.getDay()];
        const h  = String(date.getHours()).padStart(2, '0');
        const min = String(date.getMinutes()).padStart(2, '0');
        const s  = String(date.getSeconds()).padStart(2, '0');
        const ms = String(date.getMilliseconds()).padStart(3, '0');

        return `${y}年${m}月${d}日 (${w}) ${h}時${min}分${s}秒${ms}ミリ秒`;
    }

    function getCurrentStatusIdFromUrl() {
        const match = location.pathname.match(/\/status\/(\d+)/);
        return match ? match[1] : null;
    }

    function processFocusedTweet() {
        const statusId = getCurrentStatusIdFromUrl();
        if (!statusId) return;

        // URLが変わった（新しい詳細ページに遷移した）場合のみリセット
        if (statusId !== currentStatusId) {
            currentStatusId = statusId;
            processedMainTweet = false;
        }

        // すでに処理済みなら何もしない
        if (processedMainTweet) return;

        // メインカラム内の**最初の** tweet article の time を対象に
        // （親ツイートはほぼ確実に一番上にある）
        const mainTweetTime = document.querySelector(
            '[data-testid="primaryColumn"] article[data-testid="tweet"]:first-of-type time:not([data-ms-processed])'
        );

        if (!mainTweetTime) return;

        const link = mainTweetTime.closest('a');
        if (!link) return;

        const href = link.href;
        const idMatch = href.match(/status\/(\d+)/);
        if (!idMatch || idMatch[1] !== statusId) return;  // 念のためID一致確認

        const tweetId = BigInt(idMatch[1]);
        const timestampMs = Number((tweetId >> 22n) + BigInt(twitterEpoch));

        const date = new Date(timestampMs);
        const fullStr = formatFullJapaneseDate(date);

        mainTweetTime.title = fullStr;
        mainTweetTime.textContent = fullStr;

        // 処理済みマーク（このtime要素専用）
        mainTweetTime.dataset.msProcessed = 'true';

        // このstatusページの親は処理済みフラグを立てる
        processedMainTweet = true;

        // 見た目調整（任意・長い文字列なので小さめに）
        // mainTweetTime.style.fontSize = "0.92em";
        // mainTweetTime.style.lineHeight = "1.4";
    }

    // ページ読み込み直後 + URL変更時（SPAなのでpopstateで検知）
    function onPageChange() {
        processFocusedTweet();
    }

    onPageChange();  // 初回

    // SPA遷移検知（Xはhistory APIを使うので）
    let lastUrl = location.href;
    new MutationObserver(() => {
        if (location.href !== lastUrl) {
            lastUrl = location.href;
            onPageChange();
        }
        // DOM変化時も念のためチェック（遅延読み込み対策）
        processFocusedTweet();
    }).observe(document.body, { childList: true, subtree: true });

    // popstateイベントでも対応（ブラウザ戻る/進む）
    window.addEventListener('popstate', onPageChange);
})();