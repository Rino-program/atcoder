// ==UserScript==
// @name         AtCoderChristmasTree
// @namespace    https://github.com/ohirugoha-n/AtCoderChristmasTree
// @version      0.1.0
// @description  AtCoderのユーザーページのレーティング瓦をクリスマスツリーにします
// @author       ohirugohan
// @match        https://atcoder.jp/users/*
// @grant        none
// @license      MIT
// @downloadURL https://update.greasyfork.org/scripts/583325/AtCoderChristmasTree.user.js
// @updateURL https://update.greasyfork.org/scripts/583325/AtCoderChristmasTree.meta.js
// ==/UserScript==

(function() {
  'use strict';

  const kawara = document.getElementsByClassName("user-rating-stage-l");
  const star_elem = document.getElementsByClassName("fav-btn")[0];
  if(kawara.length != 1) return;
  const kawara_elem = kawara[0];

  star_elem.parentElement.insertBefore(star_elem, kawara_elem);

  const src = kawara_elem.getAttribute("src");
  const height = src[src.length-5] - '0';

  kawara_elem.style.position = "relative";
  star_elem.style.position = "absolute";
  star_elem.style.marginLeft = "7px";
  star_elem.style.marginTop = (12 + height*-6) + "px";
  star_elem.style.zIndex = "1";
})();
