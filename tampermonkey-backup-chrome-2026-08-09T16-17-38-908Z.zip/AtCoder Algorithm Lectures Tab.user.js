// ==UserScript==
// @name         AtCoder Algorithm Lectures Tab
// @namespace    https://rino-program.github.io/WEBHub/
// @version      1.0.3
// @description  AtCoderのナビゲーションバーの末尾にAtCoder Algorithm Lecturesへのリンクを追加する
// @author       Rino-program
// @match        https://atcoder.jp/*
// @grant        none
// @license      MIT
// @downloadURL https://update.greasyfork.org/scripts/581144/AtCoder%20Algorithm%20Lectures%20Tab.user.js
// @updateURL https://update.greasyfork.org/scripts/581144/AtCoder%20Algorithm%20Lectures%20Tab.meta.js
// ==/UserScript==

(function () {
    'use strict';

    window.addEventListener('load', () => {
        const menuList = document.querySelector('ul.header-page');

        if (menuList) {
            // href を空（javascript:void(0)）にして、id を付与
            const lectureTabHtml = `
                <li>
                    <a href="javascript:void(0);" id="algo-lecture-link">
                        <span>AtCoder Algorithm Lectures</span>
                    </a>
                </li>
            `;

            menuList.insertAdjacentHTML('beforeend', lectureTabHtml);

            // クリックされたときに、余計なパラメータを挟まず直接URLを開く
            const linkElement = document.getElementById('algo-lecture-link');
            if (linkElement) {
                linkElement.addEventListener('click', (e) => {
                    e.preventDefault();
                    window.open('https://info.atcoder.jp/entry/algorithm_lectures/index', '_blank', 'noopener,noreferrer');
                });
            }
        }
    });
})();