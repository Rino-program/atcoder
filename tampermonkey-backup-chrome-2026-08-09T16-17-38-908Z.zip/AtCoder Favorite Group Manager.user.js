// ==UserScript==
// @name            AtCoder Favorite Group Manager
// @name:en         AtCoder Favorite Group Manager
// @namespace       https://kiramku.f5.si/
// @version         1.2.16
// @description     AtCoderのお気に入り順位表とお気に入りのレーティング変動をグループでフィルタリングすることができます
// @description:en  Filter favorite standings and rating changes by group.
// @author          kirameku
// @icon            https://atcoder.jp/favicon.ico
// @match           https://atcoder.jp/*
// @exclude         https://atcoder.jp/topsic*
// @exclude         https://atcoder.jp/*/json
// @grant           unsafeWindow
// @grant           GM_setValue
// @grant           GM_getValue
// @grant           GM_addStyle
// @run-at          document-start
// @license         MIT
// @downloadURL https://update.greasyfork.org/scripts/583889/AtCoder%20Favorite%20Group%20Manager.user.js
// @updateURL https://update.greasyfork.org/scripts/583889/AtCoder%20Favorite%20Group%20Manager.meta.js
// ==/UserScript==

(function() {
    'use strict';

    const viewWindow = typeof unsafeWindow !== 'undefined' ? unsafeWindow : window;

    const GROUPS_STORAGE_KEY = 'atcoder_user_groups';
    const GROUP_ORDER_STORAGE_KEY = 'atcoder_group_order';
    const FILTER_STATE_STORAGE_KEY = 'atcoder_filter_state';

    let currentEditingGroup = null;
    let originalEditingGroup = null;
    let currentEditingGroupNameTarget = null;

    // ★ 各検索ボックスのモードを個別に管理
    let searchModes = {
        group: 'normal',   // フィルター管理内のグループ名検索
        user: 'normal',    // メンバー編集内のお気に入りユーザー検索
        userSort: 'abc',   // ★ 'abc' (アルファベット順・初期値) または 'order' (登録順)
        userReverse: false,// ★ 左側タブの逆順フラグ
        member: 'normal',   // メンバー編集内の所属メンバー検索
        memberSort: 'order', // 'order' (登録順) または 'abc' (アルファベット順)
        memberReverse: false // ★ 右側タブの逆順フラグ
    };

    let isSyncing = false;

    // --- データ管理 ---
    function initializeGroups() {
        if (GM_getValue(GROUPS_STORAGE_KEY) === undefined) {
            GM_setValue(GROUPS_STORAGE_KEY, JSON.stringify({}));
        }
        return getGroups();
    }
    function saveGroups(groups) { GM_setValue(GROUPS_STORAGE_KEY, JSON.stringify(groups)); }
    function getGroups() { return JSON.parse(GM_getValue(GROUPS_STORAGE_KEY, '{}')); }
    function saveGroupOrder(order) { GM_setValue(GROUP_ORDER_STORAGE_KEY, JSON.stringify(order)); }
    function getGroupOrder() {
        const order = GM_getValue(GROUP_ORDER_STORAGE_KEY);
        if (!order) { const defaultOrder = Object.keys(getGroups()); saveGroupOrder(defaultOrder); return defaultOrder; }
        return JSON.parse(order);
    }

    function saveFilterState(state) { GM_setValue(FILTER_STATE_STORAGE_KEY, JSON.stringify(state)); }
    function getFilterState() {
        const state = GM_getValue(FILTER_STATE_STORAGE_KEY);
        if (!state) return { noneChecked: true, selectedGroups: [], operation: 'OR', hideAbsent: false };

        const filterState = JSON.parse(state);
        const existingNames = Object.keys(getGroups());

        filterState.selectedGroups = (filterState.selectedGroups || []).filter(g => existingNames.includes(g));

        if (filterState.selectedGroups.length === 0) {
            filterState.noneChecked = true;
        }
        if (filterState.hideAbsent === undefined) filterState.hideAbsent = false;
        return filterState;
    }

    // --- カスタム通知・確認モーダル ---
    function showCustomAlert(message, title = '通知') {
        if (message && (message.includes('429') || message.toLowerCase().includes('too many requests') || message.includes('status: 4'))) {
            return;
        }
        const modal = document.getElementById('customAlertModal');
        if (!modal) return;
        document.getElementById('customAlertTitle').textContent = title;
        document.getElementById('customAlertBody').textContent = message;
        openBootstrapModal('customAlertModal');
    }

    function showCustomConfirm(message, onConfirm, title = '確認') {
        const modal = document.getElementById('customConfirmModal');
        if (!modal) return;
        document.getElementById('customConfirmTitle').textContent = title;
        document.getElementById('customConfirmBody').textContent = message;

        const okBtn = document.getElementById('customConfirmOkBtn');
        const newOkBtn = okBtn.cloneNode(true);
        okBtn.replaceWith(newOkBtn);

        newOkBtn.addEventListener('click', (e) => {
            e.preventDefault();
            closeBootstrapModal('customConfirmModal');
            onConfirm();
        });

        openBootstrapModal('customConfirmModal');
    }

    // --- JSON機能 ---
    function exportFilterDataAsJSON() {
        const data = { groups: getGroups(), order: getGroupOrder(), filterState: getFilterState() };
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `atcoder_filter_backup_${new Date().toISOString().slice(0,10)}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    function importFilterDataFromJSON(event) {
        const file = event.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = function(e) {
            try {
                const data = JSON.parse(e.target.result);
                if (data && data.groups && data.order && data.filterState) {
                    saveGroups(data.groups); saveGroupOrder(data.order); saveFilterState(data.filterState);
                    showCustomAlert('フィルターデータを正常にインポートしました', 'インポート完了');
                    const groupInput = document.getElementById('groupSearchInput');
                    if (groupInput) groupInput.value = '';
                    updateModalContent(); updateClearButtonState(); syncVueFavSet();
                } else {
                    showCustomAlert('無効なバックアップファイル形式です', 'インポートエラー');
                }
            } catch (err) {
                showCustomAlert('JSONの解析に失敗しました', 'インポートエラー');
                console.error(err);
            }
            event.target.value = '';
        };
        reader.readAsText(file);
    }

    function getOriginalAtCoderFavorites() {
        if (typeof viewWindow.getLS === 'function') { const favData = viewWindow.getLS('fav'); if (Array.isArray(favData)) return favData; }
        if (typeof viewWindow.favs !== 'undefined' && Array.isArray(viewWindow.favs)) { return viewWindow.favs; }
        return [];
    }

    function getVueInstance() {
        const allElements = document.querySelectorAll('*');
        for (const el of allElements) {
            if (el.__vue__) {
                const vm = el.__vue__;
                if (vm.standings || vm.results || vm.filteredStandings) return vm;
            }
        }
        if (typeof viewWindow.vueStandings !== 'undefined' && viewWindow.vueStandings !== null) return viewWindow.vueStandings;
        if (typeof viewWindow.vueResults !== 'undefined' && viewWindow.vueResults !== null) return viewWindow.vueResults;
        return null;
    }

    // --- フィルター状態適用ロジック ---
    function getFilterTargetUsersSet() {
        const filterState = getFilterState();
        const isFilterActive = !filterState.noneChecked && filterState.selectedGroups.length > 0;
        const targetUsers = new Set();
        if (isFilterActive) {
            const groups = getGroups();
            if (filterState.operation === 'OR') {
                filterState.selectedGroups.forEach(name => { if (groups[name]) groups[name].forEach(u => targetUsers.add(u)); });
            } else {
                if (filterState.selectedGroups.length > 0) {
                    let intersect = new Set(groups[filterState.selectedGroups[0]] || []);
                    for (let i = 1; i < filterState.selectedGroups.length; i++) {
                        const nextSet = new Set(groups[filterState.selectedGroups[i]] || []);
                        intersect = new Set([...intersect].filter(u => nextSet.has(u)));
                    }
                    intersect.forEach(u => targetUsers.add(u));
                }
            }
        } else {
            // 【変更】forEachループを廃止して一括生成
            return new Set(getOriginalAtCoderFavorites());
        }
        return targetUsers;
    }

    function createProtectedFavSet(allowedSet, isFilterActive) {
        const protectedSet = new Set(allowedSet);
        if (isFilterActive) {
            const originalAdd = protectedSet.add;
            protectedSet.add = function(value) {
                if (value && allowedSet.has(value)) { return originalAdd.call(this, value); }
                return this;
            };
        }
        return protectedSet;
    }

    function filterRowData(row, isFilterActive, targetSet, hideAbsent) {
        const favCheckbox = document.getElementById("checkbox-fav-only");
        if (favCheckbox && !favCheckbox.checked) return true;
        const username = row.UserScreenName || (row.UserAttributes && row.UserAttributes.UserScreenName) || row.UserName;
        if (!username) return false;
        if (isFilterActive && !targetSet.has(username)) return false;
        if (hideAbsent) {
            const hasSubmitted = row.TotalResult && (row.TotalResult.Count > 0 || row.TotalResult.Score > 0 || row.Rank > 0);
            return !!hasSubmitted;
        }
        return true;
    }

    function hijackFilteredStandings(vm) {
        if (!vm || vm._filteredStandingsHijacked) return;
        const originalPropDesc = Object.getOwnPropertyDescriptor(vm, 'filteredStandings') ||
              Object.getOwnPropertyDescriptor(Object.getPrototypeOf(vm), 'filteredStandings');
        const originalGetter = originalPropDesc ? originalPropDesc.get : null;

        Object.defineProperty(vm, 'filteredStandings', {
            get: function() {
                // 1. お気に入り表示のフラグ状態を正確に取得
                const isFavOnly = this.showFavOnly || this.favOnly || this.favsOnly;
                const filterState = getFilterState();
                const isFilterActive = !filterState.noneChecked && filterState.selectedGroups.length > 0;

                // ★【超高速化ガード】お気に入りオフ、またはフィルターも不参加者非表示も指定していない時は、
                // 拡張機能の重い配列ループ処理を一切走らせず、公式本来のデータを最速でそのまま返す
                if (!isFavOnly || (!isFilterActive && !filterState.hideAbsent)) {
                    try {
                        if (originalGetter) return originalGetter.call(this);
                        if (this._computedWatchers && this._computedWatchers.filteredStandings) {
                            return this._computedWatchers.filteredStandings.value;
                        }
                    } catch (e) { return null; }
                }

                // --- 以降は絞り込みが必要な時だけ実行される安全な領域 ---
                let baseData = null;
                try {
                    if (originalGetter) baseData = originalGetter.call(this);
                    else if (this._computedWatchers && this._computedWatchers.filteredStandings) baseData = this._computedWatchers.filteredStandings.value;
                } catch (e) { return null; }
                if (!baseData) return baseData;

                const targetSet = getFilterTargetUsersSet();

                if (Array.isArray(baseData)) {
                    return baseData.filter(row => filterRowData(row, isFilterActive, targetSet, filterState.hideAbsent));
                }
                const clonedResult = Object.assign({}, baseData);
                if (Array.isArray(clonedResult.rows)) clonedResult.rows = clonedResult.rows.filter(row => filterRowData(row, isFilterActive, targetSet, filterState.hideAbsent));
                if (Array.isArray(clonedResult.StandingsData)) clonedResult.StandingsData = clonedResult.StandingsData.filter(row => filterRowData(row, isFilterActive, targetSet, filterState.hideAbsent));
                return clonedResult;
            },
            set: function(val) { if (originalPropDesc && originalPropDesc.set) originalPropDesc.set.call(this, val); },
            configurable: true,
            enumerable: true
        });
        vm._filteredStandingsHijacked = true;
    }

    function hijackCurrentResults(vm) {
        if (!vm || vm._currentResultsHijacked) return;

        const originalPropDesc = Object.getOwnPropertyDescriptor(vm, 'currentResults') ||
              Object.getOwnPropertyDescriptor(Object.getPrototypeOf(vm), 'currentResults');
        const originalGetter = originalPropDesc ? originalPropDesc.get : null;

        Object.defineProperty(vm, 'currentResults', {
            get: function() {
                let baseData = null;
                try {
                    if (originalGetter) baseData = originalGetter.call(this);
                    else if (this._computedWatchers && this._computedWatchers.currentResults) baseData = this._computedWatchers.currentResults.value;
                } catch (e) { return null; }

                if (!baseData || !Array.isArray(baseData)) return baseData;

                // お気に入り表示のフラグ状態を取得
                const isFavOnly = this.showFavOnly || this.favOnly || this.favsOnly;

                // お気に入りのみ表示がオン、かつグループフィルターがアクティブな時だけ絞り込む
                if (isFavOnly) {
                    const filterState = getFilterState();
                    const isFilterActive = !filterState.noneChecked && filterState.selectedGroups.length > 0;

                    if (isFilterActive) {
                        const targetSet = getFilterTargetUsersSet();

                        // ★ 公式の検索・ソート後のリスト（orderedResults）に含まれているユーザー名の Set を作成
                        const validSearchResultUsers = new Set();
                        if (Array.isArray(this.orderedResults)) {
                            this.orderedResults.forEach(r => {
                                if (!r) return;
                                const uname = r.UserScreenName || r.UserName || (r.UserAttributes && r.UserAttributes.UserScreenName);
                                if (uname) validSearchResultUsers.add(uname);
                            });
                        }

                        return baseData.filter(row => {
                            if (!row) return false;

                            // ユーザー名の取得
                            let username = row.UserScreenName || row.UserName;
                            if (!username && row.UserAttributes) {
                                username = row.UserAttributes.UserScreenName || row.UserAttributes.UserName;
                            }
                            if (!username && row.user) {
                                username = typeof row.user === 'string' ? row.user : (row.user.UserScreenName || row.user.UserName);
                            }

                            if (!username && row === this.me && this.me) {
                                username = this.me.UserScreenName || this.me.UserName || (this.me.UserAttributes && this.me.UserAttributes.UserScreenName);
                            }

                            if (!username) return false;

                            // 1. グループターゲットに含まれているか
                            const inGroup = targetSet.has(username);

                            // 2. 検索結果（orderedResults）に含まれているか
                            const inSearchResult = validSearchResultUsers.has(username);

                            // 両方の条件を満たす場合のみ表示
                            return inGroup && inSearchResult;
                        });
                    }
                }

                // お気に入りがオフの時は公式データをそのまま返す
                return baseData;
            },
            set: function(val) { if (originalPropDesc && originalPropDesc.set) originalPropDesc.set.call(this, val); },
            configurable: true,
            enumerable: true
        });
        vm._currentResultsHijacked = true;
    }

    function updateExtensionUIState(isFavOnly) {
        // 1. 外側の「不参加者非表示」チェックボックスのみを制御対象にする
        const hideAbsentCheckbox = document.getElementById("checkbox-hide-absent");
        if (hideAbsentCheckbox) {
            hideAbsentCheckbox.disabled = !isFavOnly;

            // ★ 勝手にオフになるのを防ぐため、ストレージから最新の値を強制的に再適用
            const state = getFilterState();
            hideAbsentCheckbox.checked = !!state.hideAbsent;
        }

        // 2. フィルター管理ボタン（グループ選択ボタン）のみをグレーアウト制御
        const filterButtons = document.querySelectorAll(
            '.atcoder-filter-button-container button.filtering-by-group-btn'
        );

        filterButtons.forEach(btn => {
            if (isFavOnly) {
                btn.disabled = false;
                btn.classList.remove('disabled-grayout');
            } else {
                btn.disabled = true;
                btn.classList.add('disabled-grayout');
            }
        });

        // 3. 解除ボタンの見た目を一元管理関数に委ねる
        updateClearButtonState();
    }

    // === 【追加】チェックボックス切り替え直前の割り込み処理（syncVueFavSetの直前に記述） ===
    document.addEventListener('change', function(e) {
        if (e.target && e.target.id === 'checkbox-fav-only') {
            const vm = getVueInstance();
            if (!vm) return;

            const willBeChecked = e.target.checked;
            const filterState = getFilterState();
            const isFilterActive = !filterState.noneChecked && filterState.selectedGroups.length > 0;

            if (!willBeChecked) {
                // OFFになる瞬間：即座に元の全お気に入りSetに復元して星マーク判定の誤判定（一瞬星が消える現象）を防止
                if (vm._originalFavSet) {
                    vm.favSet = vm._originalFavSet;
                }
            } else if (isFilterActive) {
                // ONになる瞬間：即座にグループ絞り込みSetにして元順位が一瞬表示される現象を防止
                const targetSet = getFilterTargetUsersSet();
                vm.favSet = createProtectedFavSet(targetSet, true);
            }

            // Computedのキャッシュを即時破棄して次のVue描画時に直前の状態を参照させる
            if (vm._computedWatchers) {
                if (vm._computedWatchers.filteredStandings) vm._computedWatchers.filteredStandings.dirty = true;
                if (vm._computedWatchers.currentResults) vm._computedWatchers.currentResults.dirty = true;
            }
        }
    }, true); // ★ capture: true で Vue より先に処理させる

    function syncVueFavSet() {
        const vm = getVueInstance();
        if (!vm || isSyncing) return;
        isSyncing = true;
        try {
            // ★ 最初にストレージから現在のフィルター状態を厳格に取得
            let filterState = getFilterState();

            if ('showAbsent' in vm) {
                vm.showAbsent = !filterState.hideAbsent;
            }

            // モーダルが開いていて、チェックボックスが存在する場合のみ同期
            const modalHideAbsentCheckbox = document.getElementById("modal-checkbox-hide-absent");
            const modalIsOpen = document.getElementById('groupFilterModal')?.classList.contains('in');
            if (modalHideAbsentCheckbox && modalIsOpen) {
                filterState.hideAbsent = modalHideAbsentCheckbox.checked;
                saveFilterState(filterState);
            }

            const isFilterActive = !filterState.noneChecked && filterState.selectedGroups.length > 0;
            const targetSet = getFilterTargetUsersSet();

            hijackFilteredStandings(vm);
            hijackCurrentResults(vm);

            const favCheckbox = document.getElementById("checkbox-fav-only");
            const isFavCheckboxChecked = favCheckbox ? favCheckbox.checked : false;

            if (!vm._originalFavSet) {
                vm._originalFavSet = vm.favSet || new Set(getOriginalAtCoderFavorites());
            }

            if (isFavCheckboxChecked && isFilterActive) {
                vm.favSet = createProtectedFavSet(targetSet, true);
            } else {
                // フィルター解除時はキャッシュ済みの元Setを直接代入して高速化
                vm.favSet = vm._originalFavSet;
            }

            // ★ 公式側のVueインスタンスに対して、ストレージから取得した状態を強制注入
            if ('showAbsent' in vm) {
                vm.showAbsent = !filterState.hideAbsent;
            }

            if (isFilterActive && isFavCheckboxChecked) {
                if ('favOnly' in vm && vm.favOnly !== true) vm.favOnly = true;
                if ('favsOnly' in vm && vm.favsOnly !== true) vm.favsOnly = true;
            }

            if (favCheckbox && 'favOnly' in vm) {
                favCheckbox.checked = vm.favOnly;
                // 引数には現在の正確な状態を渡す
                updateExtensionUIState(vm.favOnly);
            } else if (favCheckbox) {
                updateExtensionUIState(favCheckbox.checked);
            }

            // Vueの Computed watcher のキャッシュ破棄と強制評価
            if (vm._computedWatchers) {
                if (vm._computedWatchers.filteredStandings) {
                    vm._computedWatchers.filteredStandings.dirty = true;
                    try { vm._computedWatchers.filteredStandings.evaluate(); } catch(e){}
                }
                if (vm._computedWatchers.currentResults) {
                    vm._computedWatchers.currentResults.dirty = true;
                    try { vm._computedWatchers.currentResults.evaluate(); } catch(e){}
                }
            }

            // Vueのコンポーネントを強制再描画
            if (typeof vm.$forceUpdate === 'function') {
                vm.$forceUpdate();
            }

            updateClearButtonState();

        } catch (error) {
            console.error("[AtCoder Favorite Group Manager] 同期エラー:", error);
        } finally {
            isSyncing = false;
        }
    }

    // --- モーダル制御・UI構築 ---
    function openBootstrapModal(id, updateFn = null) {
        if (updateFn) updateFn();
        if (viewWindow.$ && typeof viewWindow.$ === 'function') viewWindow.$(`#${id}`).modal('show');
        else if (window.$ && typeof window.$ === 'function') window.$(`#${id}`).modal('show');
    }
    function closeBootstrapModal(id) {
        if (viewWindow.$ && typeof viewWindow.$ === 'function') viewWindow.$(`#${id}`).modal('hide');
        else if (window.$ && typeof window.$ === 'function') window.$(`#${id}`).modal('hide');
    }

    function clearFiltering() {
        const state = getFilterState();

        // ★ グループ選択のみを初期化し、hideAbsent（不参加者非表示）の状態はそのまま保持する
        state.noneChecked = true;
        state.selectedGroups = [];
        state.operation = 'OR';
        saveFilterState(state);

        // グループ名検索入力をクリア
        const groupInput = document.getElementById('groupSearchInput');
        if (groupInput) groupInput.value = '';

        // モーダル内のグループ関連のDOM要素をリセット
        const noneFilterCheckbox = document.getElementById('noneFilter');
        if (noneFilterCheckbox) noneFilterCheckbox.checked = true;

        const orRadio = document.querySelector('input[name="operation"][value="OR"]');
        if (orRadio) orRadio.checked = true;

        // グループのチェックボックスのみを外す
        document.querySelectorAll('#groupFilterTableBody input[type="checkbox"]').forEach(cb => {
            cb.checked = false;
        });

        // モーダル内のコンテンツを描画更新
        updateModalContent();

        // すべての解除ボタンをその場で即時グレーアウト（グループが空になったため）
        const clearButtons = document.querySelectorAll('#innerClearFilteringBtn, #outerClearFilteringBtn, .clear-filtering-outer-btn');
        clearButtons.forEach(btn => {
            btn.disabled = true;
            btn.classList.add('disabled-grayout');
            btn.style.opacity = "0.5";
        });

        // Vueインスタンスの状態を同期
        isSyncing = false;
        syncVueFavSet();
    }

    function saveGroupFilterModalStateAuto() { const modal = document.getElementById('groupFilterModal'); if (!modal) return; const selectedGroups = []; modal.querySelectorAll('input[data-group]:checked').forEach(cb => { selectedGroups.push(cb.dataset.group); }); const noneFilterCb = document.getElementById('noneFilter'); const noneChecked = noneFilterCb ? noneFilterCb.checked : (selectedGroups.length === 0); const opRadio = modal.querySelector('input[name="operation"]:checked'); const operation = opRadio ? opRadio.value : 'OR'; const state = getFilterState(); state.noneChecked = noneChecked; state.selectedGroups = selectedGroups; state.operation = operation; saveFilterState(state); updateClearButtonState(); }

    function openEditGroupModal(groupName) {
        const groups = getGroups();
        currentEditingGroup = groups[groupName] ? [...groups[groupName]] : [];
        originalEditingGroup = groups[groupName] ? [...groups[groupName]] : [];
        currentEditingGroupNameTarget = groupName;
        document.getElementById('editGroupHeader').textContent = `メンバー編集: ${groupName}`;

        openBootstrapModal('editGroupModal', () => {
            updateEditGroupContent();
        });
    }
    function saveEditGroupMembers() { const groups = getGroups(); groups[currentEditingGroupNameTarget] = currentEditingGroup || []; saveGroups(groups); closeBootstrapModal('editGroupModal'); const groupInput = document.getElementById('groupSearchInput'); if (groupInput) groupInput.value = ''; updateModalContent(); saveGroupFilterModalStateAuto(); syncVueFavSet(); }
    function checkEditGroupModalCancel() { if (JSON.stringify(currentEditingGroup) !== JSON.stringify(originalEditingGroup)) { showCustomConfirm('変更が保存されていません。変更を破棄してもよろしいですか？', () => { currentEditingGroup = originalEditingGroup = currentEditingGroupNameTarget = null; closeBootstrapModal('editGroupModal'); }); return; } currentEditingGroup = originalEditingGroup = currentEditingGroupNameTarget = null; closeBootstrapModal('editGroupModal'); }
    function openCreateGroupModal() { const input = document.getElementById('newGroupNameInput'); input.value = ''; openBootstrapModal('createGroupModal'); setTimeout(() => input.focus(), 500); }
    function confirmCreateGroup() {
        const input = document.getElementById('newGroupNameInput');
        let groupName = input.value.trim();
        const groups = getGroups();

        // ★ 修正：もしグループ名が未入力（空欄）の場合
        if (!groupName) {
            // 現在のグループ数（Object.keys(groups).length）を取得して「新規グループ(数)」を作る
            // ※ 1つ目なら「新規グループ(1)」になるように +1 しています
            const nextNumber = Object.keys(groups).length + 1;
            let tyofkuNumber = 1;
            if(Object.keys(groups).includes(`新規グループ${nextNumber}`)) {
                while(Object.keys(groups).includes(`新規グループ${nextNumber} (${tyofkuNumber})`)) {
                    tyofkuNumber += 1;
                }
            }
            if(Object.keys(groups).includes(`新規グループ${nextNumber}`)) groupName = `新規グループ${nextNumber} (${tyofkuNumber})`;
            else groupName = `新規グループ${nextNumber}`;
        }

        // 重複チェック
        if (Object.keys(groups).includes(groupName)) {
            showCustomAlert('そのグループ名は既に存在します', '作成エラー');
            return;
        }

        // グループ作成と保存処理
        groups[groupName] = [];
        saveGroups(groups);

        const order = getGroupOrder();
        order.push(groupName);
        saveGroupOrder(order);

        closeBootstrapModal('createGroupModal');

        const groupInput = document.getElementById('groupSearchInput');
        if (groupInput) groupInput.value = '';

        updateModalContent();
    }

    function openRenameGroupModal(oldName) { currentEditingGroupNameTarget = oldName; const input = document.getElementById('renameGroupNameInput'); input.value = oldName; openBootstrapModal('renameGroupModal'); setTimeout(() => input.select(), 500); }

    function confirmRenameGroup() {
        const input = document.getElementById('renameGroupNameInput');
        const newName = input.value.trim();
        const oldName = currentEditingGroupNameTarget;
        if (!newName || newName === oldName) { closeBootstrapModal('renameGroupModal'); return; }
        const groups = getGroups();
        if (Object.keys(groups).includes(newName)) {
            closeBootstrapModal('renameGroupModal');
            showCustomAlert('そのグループ名は既に存在します', '名前変更エラー');
            return;
        }
        groups[newName] = groups[oldName]; delete groups[oldName]; saveGroups(groups);
        const order = getGroupOrder(); const idx = order.indexOf(oldName); if (idx !== -1) { order[idx] = newName; saveGroupOrder(order); }
        const filterState = getFilterState(); const sIdx = filterState.selectedGroups.indexOf(oldName); if (sIdx !== -1) { filterState.selectedGroups[sIdx] = newName; saveFilterState(filterState); }
        currentEditingGroupNameTarget = null; closeBootstrapModal('renameGroupModal'); const groupInput = document.getElementById('groupSearchInput'); if (groupInput) groupInput.value = ''; updateModalContent();
    }

    function addDragEvents(groupItem) { const dragBtn = groupItem.querySelector('.group-drag-handle'); if (!dragBtn) return; dragBtn.addEventListener('mousedown', () => { groupItem.draggable = true; }, { passive: true }); groupItem.addEventListener('mousedown', e => { if (!e.target.classList.contains('group-drag-handle')) groupItem.draggable = false; }, { passive: true }); groupItem.addEventListener('dragstart', function(e) { this.classList.add('dragging'); e.dataTransfer.setData('text/plain', this.dataset.groupName); }, { passive: true }); groupItem.addEventListener('dragend', function() { this.classList.remove('dragging'); }, { passive: true }); groupItem.addEventListener('dragover', e => { e.preventDefault(); groupItem.classList.add('list-group-item-info'); }, { passive: false }); groupItem.addEventListener('dragleave', () => { groupItem.classList.remove('list-group-item-info'); }, { passive: true }); groupItem.addEventListener('drop', function(e) { e.preventDefault(); this.classList.remove('list-group-item-info'); const dragged = e.dataTransfer.getData('text/plain'); const target = this.dataset.groupName; if (dragged !== target) { const order = getGroupOrder(); const dIdx = order.indexOf(dragged); const tIdx = order.indexOf(target); if (dIdx !== -1 && tIdx !== -1) { order.splice(dIdx, 1); order.splice(tIdx, 0, dragged); saveGroupOrder(order); const groupInput = document.getElementById('groupSearchInput'); if (groupInput) groupInput.value = ''; updateModalContent(); saveGroupFilterModalStateAuto(); syncVueFavSet(); } } }, { passive: false }); }

    // --- メンバー編集モーダル内のUI・個別検索ロジック ---
    function updateEditGroupContent() {
        setupUserSearch();
        setupMemberSearch();

        // ★ モーダルを開いた初期状態ではボタンの disabled を解除
        const sortToggleBtn = document.getElementById('userSortToggleBtn');
        if (sortToggleBtn) sortToggleBtn.disabled = false;
        const sortToggleBtn2 = document.getElementById('memberSortToggleBtn');
        if (sortToggleBtn2) sortToggleBtn2.disabled = false;

        handleUserSearch();
        handleMemberSearch();
    }

    function setupUserSearch() {
        const searchInput = document.getElementById('userSearchInput');
        const toggleBtn = document.getElementById('userSearchModeToggleBtn');
        const sortToggleBtn = document.getElementById('userSortToggleBtn');
        const reverseToggleBtn = document.getElementById('userReverseToggleBtn');
        if (!searchInput || !toggleBtn || !sortToggleBtn || !reverseToggleBtn) return;

        searchInput.replaceWith(searchInput.cloneNode(true));
        toggleBtn.replaceWith(toggleBtn.cloneNode(true));
        sortToggleBtn.replaceWith(sortToggleBtn.cloneNode(true));
        reverseToggleBtn.replaceWith(reverseToggleBtn.cloneNode(true));

        const newInput = document.getElementById('userSearchInput');
        const newToggleBtn = document.getElementById('userSearchModeToggleBtn');
        const newSortToggleBtn = document.getElementById('userSortToggleBtn');
        const newReverseToggleBtn = document.getElementById('userReverseToggleBtn');

        // 入力時に入力内容の有無に応じてボタンの活性/非活性を切り替える
        newInput.addEventListener('input', () => {
            if (newInput.value.trim()) {
                newSortToggleBtn.disabled = true;
                newSortToggleBtn.textContent = 'ABC順';
            } else {
                newSortToggleBtn.disabled = false;
                applySortState();
            }
            handleUserSearch();
        }, { passive: true });
        newInput.value = '';

        const applyState = () => {
            if (searchModes.user === 'regex') {
                newToggleBtn.classList.add('active');
                newToggleBtn.textContent = '正規表現';
                newInput.placeholder = '正規表現で検索...';
            } else {
                newToggleBtn.classList.remove('active');
                newToggleBtn.textContent = '前方一致';
                newInput.placeholder = '前方一致で検索...';
            }
        };

        const applySortState = () => {
            if (searchModes.userSort === 'abc') {
                newSortToggleBtn.classList.add('active');
                newSortToggleBtn.textContent = 'ABC順';
            } else {
                newSortToggleBtn.classList.remove('active');
                newSortToggleBtn.textContent = '初期順';
            }
            newReverseToggleBtn.textContent = searchModes.userReverse ? '▼' : '▲';
        };

        applyState();
        applySortState();

        newToggleBtn.addEventListener('click', (e) => {
            e.preventDefault();
            searchModes.user = (searchModes.user === 'normal') ? 'regex' : 'normal';
            applyState();
            handleUserSearch();
        });

        newSortToggleBtn.addEventListener('click', (e) => {
            e.preventDefault();
            if (newSortToggleBtn.disabled) return;
            searchModes.userSort = (searchModes.userSort === 'order') ? 'abc' : 'order';
            applySortState();
            handleUserSearch();
        });

        newReverseToggleBtn.addEventListener('click', (e) => {
            e.preventDefault();
            searchModes.userReverse = !searchModes.userReverse;
            newReverseToggleBtn.textContent = searchModes.userReverse ? '▼' : '▲';
            handleUserSearch();
        });
    }

    function setupMemberSearch() {
        const memberInput = document.getElementById('memberSearchInput');
        const toggleBtn = document.getElementById('memberSearchModeToggleBtn');
        const sortToggleBtn = document.getElementById('memberSortToggleBtn');
        const reverseToggleBtn = document.getElementById('memberReverseToggleBtn');
        if (!memberInput || !toggleBtn || !sortToggleBtn || !reverseToggleBtn) return;

        memberInput.replaceWith(memberInput.cloneNode(true));
        toggleBtn.replaceWith(toggleBtn.cloneNode(true));
        sortToggleBtn.replaceWith(sortToggleBtn.cloneNode(true));
        reverseToggleBtn.replaceWith(reverseToggleBtn.cloneNode(true));

        const newMemberInput = document.getElementById('memberSearchInput');
        const newToggleBtn = document.getElementById('memberSearchModeToggleBtn');
        const newSortToggleBtn = document.getElementById('memberSortToggleBtn');
        const newReverseToggleBtn = document.getElementById('memberReverseToggleBtn');

        newMemberInput.addEventListener('input', () => {
            if (newMemberInput.value.trim()) {
                newSortToggleBtn.disabled = true;
                newSortToggleBtn.textContent = 'ABC順';
            } else {
                newSortToggleBtn.disabled = false;
                applySortState();
            }
            handleMemberSearch();
        }, { passive: true });
        newMemberInput.value = '';

        const applyState = () => {
            if (searchModes.member === 'regex') {
                newToggleBtn.classList.add('active');
                newToggleBtn.textContent = '正規表現';
                newMemberInput.placeholder = '正規表現でmax検索...';
            } else {
                newToggleBtn.classList.remove('active');
                newToggleBtn.textContent = '前方一致';
                newMemberInput.placeholder = '前方一致で検索...';
            }
        };

        const applySortState = () => {
            if (searchModes.memberSort === 'abc') {
                newSortToggleBtn.classList.add('active');
                newSortToggleBtn.textContent = 'ABC順';
            } else {
                newSortToggleBtn.classList.remove('active');
                newSortToggleBtn.textContent = '登録順';
            }
            newReverseToggleBtn.textContent = searchModes.memberReverse ? '▼' : '▲';
        };

        applyState();
        applySortState();

        newToggleBtn.addEventListener('click', (e) => {
            e.preventDefault();
            searchModes.member = (searchModes.member === 'normal') ? 'regex' : 'normal';
            applyState();
            handleMemberSearch();
        });

        newSortToggleBtn.addEventListener('click', (e) => {
            e.preventDefault();
            if (newSortToggleBtn.disabled) return;
            searchModes.memberSort = (searchModes.memberSort === 'order') ? 'abc' : 'order';
            applySortState();
            handleMemberSearch();
        });

        newReverseToggleBtn.addEventListener('click', (e) => {
            e.preventDefault();
            searchModes.memberReverse = !searchModes.memberReverse;
            newReverseToggleBtn.textContent = searchModes.memberReverse ? '▼' : '▲';
            handleMemberSearch();
        });
    }

    function handleUserSearch() {
        const inputEl = document.getElementById('userSearchInput');
        if (!inputEl) return;

        const query = inputEl.value.trim();

        // ★ 選択状態に応じてベースの順序を変更
        let allFavs = [];
        if (searchModes.userSort === 'abc') {
            allFavs = [...getOriginalAtCoderFavorites()].sort((a, b) => a.localeCompare(b, 'en', { sensitivity: 'base' }));
        } else {
            allFavs = [...getOriginalAtCoderFavorites()]; // 登録順（公式のデフォルト）
        }

        // ★ 逆順フラグがONなら反転
        if (searchModes.userReverse) {
            allFavs.reverse();
        }

        let filtered = [];
        if (query) {
            allFavs = [...getOriginalAtCoderFavorites()].sort((a, b) => a.localeCompare(b, 'en', { sensitivity: 'base' }));
            if (searchModes.userReverse) {
                allFavs.reverse();
            }
        }
        if (!query) {
            filtered = allFavs;
            inputEl.style.borderColor = '';
        } else if (searchModes.user === 'regex') {
            try {
                const regex = new RegExp(query, 'i');
                filtered = allFavs.filter(u => regex.test(u));
                inputEl.style.borderColor = '';
            } catch (err) {
                inputEl.style.borderColor = '#a94442';
                filtered = [];
            }
        } else {
            const term = query.toLowerCase();
            filtered = allFavs.filter(u => u.toLowerCase().startsWith(term));
            inputEl.style.borderColor = '';
        }
        updateFavoriteUsersList(filtered, currentEditingGroup || []);
    }

    function handleMemberSearch() {
        const memberInput = document.getElementById('memberSearchInput');
        if (!memberInput) return;

        const query = memberInput.value.trim();
        let groupMembers = [...(currentEditingGroup || [])];

        // 選択状態に応じて並び替え
        if (searchModes.memberSort === 'abc') {
            groupMembers.sort((a, b) => a.localeCompare(b, 'en', { sensitivity: 'base' }));
        }

        // ★ 逆順フラグがONなら反転
        if (searchModes.memberReverse) {
            groupMembers.reverse();
        }

        if (query) {
            if (searchModes.member === 'regex') {
                try {
                    const regex = new RegExp(query, 'i');
                    groupMembers = groupMembers.filter(u => regex.test(u));
                    memberInput.style.borderColor = '';
                } catch (err) {
                    memberInput.style.borderColor = '#a94442';
                    groupMembers = [];
                }
            } else {
                const term = query.toLowerCase();
                groupMembers = groupMembers.filter(u => u.toLowerCase().startsWith(term));
                memberInput.style.borderColor = '';
            }
        } else {
            memberInput.style.borderColor = '';
        }

        updateGroupMembersList(groupMembers);
    }

    function updateFavoriteUsersList(userList, groupMembers) {
        const container = document.getElementById('favoriteUsersList');
        if (!container) return;
        container.innerHTML = '';

        userList.forEach(user => {
            const inc = groupMembers.includes(user);
            const item = document.createElement('div');
            // 既存の Bootstrap クラスを維持しつつ、追加済みなら list-group-item-success を付与
            item.className = `user-item list-group-item ${inc ? 'list-group-item-success' : ''}`;

            // ★ ボタンの横幅を 50px に完全固定。追加済みなら「削除」、未追加なら「追加」
            item.innerHTML = `
                <div class="user-name">${user}</div>
                <button type="button" class="btn btn-primary custom-group-btn user-add-btn" style="width: 50px !important; padding: 4px 0 !important;">${inc ? '削除' : '追加'}</button>
            `;

            // ★ ボタンクリック時の挙動を「追加」と「削除」で分岐
            item.querySelector('.user-add-btn').addEventListener('click', (e) => {
                e.preventDefault();
                if (inc) {
                    // すでに追加されている場合は削除する処理を実行
                    if (typeof removeUserFromGroup === 'function') {
                        removeUserFromGroup(user);
                    } else if (typeof currentEditingGroup !== 'undefined') {
                        // もし専用の削除関数がなければ、配列を直接操作して再描画
                        currentEditingGroup = currentEditingGroup.filter(m => m !== user);
                        if (typeof handleUserSearch === 'function') handleUserSearch();
                        if (typeof handleMemberSearch === 'function') handleMemberSearch();
                    }
                } else {
                    // まだ追加されていない場合は追加
                    addUserToGroup(user);
                }
            });
            container.appendChild(item);
        });
    }
    function updateGroupMembersList(groupMembers) { const container = document.getElementById('groupMembersList'); if (!container) return; container.innerHTML = ''; groupMembers.forEach(user => { const item = document.createElement('div'); item.className = 'user-item list-group-item'; item.innerHTML = `<div class="user-name">${user}</div><button type="button" class="btn btn-danger custom-group-btn user-delete-btn">削除</button>`; item.querySelector('.user-delete-btn').addEventListener('click', (e) => { e.preventDefault(); removeUserFromGroup(user); }); container.appendChild(item); }); }

    function addUserToGroup(username) {
        if (!currentEditingGroup.includes(username)) {
            currentEditingGroup.push(username);
            handleUserSearch();
            handleMemberSearch();
        }
    }
    function removeUserFromGroup(username) {
        const idx = currentEditingGroup.indexOf(username);
        if (idx !== -1) {
            currentEditingGroup.splice(idx, 1);
            handleUserSearch();
            handleMemberSearch();
        }
    }

    function deleteGroup(groupName) { showCustomConfirm(`本当にグループ "${groupName}" を削除しますか？`, () => { const groups = getGroups(); delete groups[groupName]; saveGroups(groups); const order = getGroupOrder(); const idx = order.indexOf(groupName); if (idx !== -1) { order.splice(idx, 1); saveGroupOrder(order); } const state = getFilterState(); if (state.selectedGroups.includes(groupName)) { state.selectedGroups = state.selectedGroups.filter(n => n !== groupName); if (state.selectedGroups.length === 0) state.noneChecked = true; saveFilterState(state); } const groupInput = document.getElementById('groupSearchInput'); if (groupInput) groupInput.value = ''; updateModalContent(); saveGroupFilterModalStateAuto(); syncVueFavSet(); }); }

    // --- フィルター管理（グループ名）個別検索ロジック ---
    function updateModalContent() {
        const groups = getGroups(); let order = getGroupOrder(); const filterState = getFilterState(); const tbody = document.getElementById('groupFilterTableBody');
        if (!tbody) return;

        const groupInput = document.getElementById('groupSearchInput');
        const groupQuery = groupInput ? groupInput.value.trim() : '';

        if (groupQuery) {
            if (searchModes.group === 'regex') {
                try {
                    const regex = new RegExp(groupQuery, 'i');
                    order = order.filter(name => regex.test(name));
                    if (groupInput) groupInput.style.borderColor = '';
                } catch (e) {
                    if (groupInput) groupInput.style.borderColor = '#a94442';
                    order = [];
                }
            } else {
                // 通常時は「前方一致」で検索
                const term = groupQuery.toLowerCase();
                order = order.filter(name => name.toLowerCase().startsWith(term));
                if (groupInput) groupInput.style.borderColor = '';
            }
        } else if (groupInput) {
            groupInput.style.borderColor = '';
        }

        tbody.innerHTML = '';
        order.forEach(groupName => {
            if (groups[groupName]) {
                const tr = document.createElement('tr'); tr.className = 'group-row-item'; tr.draggable = true; tr.dataset.groupName = groupName;
                tr.innerHTML = `
                    <td style="vertical-align: middle; width: 40px; text-align: center; padding: 10px 8px;"><input type="checkbox" id="group_${groupName}" data-group="${groupName}" style="margin:0; width: 16px; height: 16px; cursor: pointer;"></td>
                    <td style="vertical-align: middle; padding: 10px 8px;"><label for="group_${groupName}" style="margin:0; font-weight: bold; cursor: pointer; display: block; font-size: 14px;">${groupName}</label></td>
                    <td style="vertical-align: middle; text-align: center; width: 85px; padding: 10px 8px;"><span class="label label-default" style="font-size: 11px; padding: 3px 6px;">${groups[groupName].length} users</span></td>
                    <td style="vertical-align: middle; text-align: right; width: 235px; padding: 10px 8px;">
                        <div style="display: inline-flex; align-items: center; justify-content: flex-end; width: 100%;">
                            <button type="button" class="btn btn-default custom-group-btn group-rename-btn">名前変更</button>
                            <button type="button" class="btn btn-default custom-group-btn group-edit-btn">メンバー</button>
                            <button type="button" class="btn btn-danger custom-group-btn group-delete-btn">削除</button>
                            <span class="group-drag-handle">⋮⋮</span>
                        </div>
                    </td>
                `;
                tr.querySelector('.group-rename-btn').addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); openRenameGroupModal(groupName); });
                tr.querySelector('.group-edit-btn').addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); openEditGroupModal(groupName); });
                tr.querySelector('.group-delete-btn').addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); deleteGroup(groupName); });
                addDragEvents(tr); tbody.appendChild(tr);
            }
        });
        const noneCheckbox = document.getElementById('noneFilter'); const opRadios = document.querySelectorAll('input[name="operation"]');
        if (noneCheckbox) { noneCheckbox.disabled = true; noneCheckbox.checked = filterState.noneChecked; }
        filterState.selectedGroups.forEach(g => { const cb = document.getElementById(`group_${g}`); if (cb) cb.checked = true; });
        const opRadio = document.querySelector(`input[name="operation"][value="${filterState.operation}"]`); if (opRadio) opRadio.checked = true;
        if (noneCheckbox) opRadios.forEach(r => r.disabled = noneCheckbox.checked);

        tbody.querySelectorAll('input[data-group]').forEach(cb => {
            cb.addEventListener('change', function() {
                const checkedCount = tbody.querySelectorAll('input[data-group]:checked').length;
                if (noneCheckbox) {
                    if (checkedCount === 0) { noneCheckbox.checked = true; opRadios.forEach(r => r.disabled = true); }
                    else { noneCheckbox.checked = false; opRadios.forEach(r => r.disabled = false); }
                }
                saveGroupFilterModalStateAuto(); syncVueFavSet();
            });
        });
    }

    function setupGroupSearchModeToggle() {
        const toggleBtn = document.getElementById('groupSearchModeToggleBtn');
        const groupInput = document.getElementById('groupSearchInput');
        if (!toggleBtn || !groupInput) return;

        // クローンによるイベント重複防止
        toggleBtn.replaceWith(toggleBtn.cloneNode(true));
        groupInput.replaceWith(groupInput.cloneNode(true));

        const newToggleBtn = document.getElementById('groupSearchModeToggleBtn');
        const newGroupInput = document.getElementById('groupSearchInput');

        const applyState = () => {
            if (searchModes.group === 'regex') {
                newToggleBtn.classList.add('active');
                newToggleBtn.textContent = '正規表現';
                newGroupInput.placeholder = '正規表現で検索...';
            } else {
                newToggleBtn.classList.remove('active');
                newToggleBtn.textContent = '前方一致';
                newGroupInput.placeholder = '前方一致で検索...';
            }
        };
        applyState();

        newGroupInput.addEventListener('input', () => updateModalContent(), { passive: true });
        newToggleBtn.addEventListener('click', (e) => {
            e.preventDefault();
            searchModes.group = (searchModes.group === 'normal') ? 'regex' : 'normal';
            applyState();
            updateModalContent();
        });
    }

    function getSortedAtCoderFavorites() { const favs = getOriginalAtCoderFavorites(); return [...favs].sort((a, b) => a.localeCompare(b, 'en', { sensitivity: 'base' })); }

    function updateClearButtonState() {
        const filterState = getFilterState();

        // ★ 判定条件を「グループが1つ以上選択されているか」のみに変更
        const isFilterActive = !filterState.noneChecked && filterState.selectedGroups && filterState.selectedGroups.length > 0;

        // お気に入りチェックボックス自体の状態も取得
        const favCheckbox = document.getElementById("checkbox-fav-only");
        const isFavOnly = favCheckbox ? favCheckbox.checked : false;

        // 1. モーダル内の解除ボタンの制御
        const innerClearBtn = document.getElementById('innerClearFilteringBtn');
        if (innerClearBtn) {
            if (isFilterActive) {
                innerClearBtn.disabled = false;
                innerClearBtn.classList.remove('disabled-grayout');
                innerClearBtn.style.opacity = "1";
            } else {
                innerClearBtn.disabled = true;
                innerClearBtn.classList.add('disabled-grayout');
                innerClearBtn.style.opacity = "0.5";
            }
        }

        // 2. 順位表側（外側）の解除ボタンの制御
        const outerClearButtons = document.querySelectorAll('#outerClearFilteringBtn, .clear-filtering-outer-btn');
        outerClearButtons.forEach(btn => {
            // 「お気に入りがオン」かつ「グループフィルターが有効」な時だけ光らせる
            if (isFavOnly && isFilterActive) {
                btn.disabled = false;
                btn.classList.remove('disabled-grayout');
                btn.style.opacity = "1";
            } else {
                btn.disabled = true;
                btn.classList.add('disabled-grayout');
                btn.style.opacity = "0.5";
            }
        });
    }

    function addExtensionStyles() {
        if (typeof GM_addStyle !== 'function') return;
        GM_addStyle(`
            html, body, html.modal-open, body.modal-open {
                padding-right: 0px !important;
                margin-right: 0px !important;
                overflow: initial !important;
            }

            .navbar-fixed-top, .navbar-fixed-bottom, .navbar, header, nav, #header,
            .modal-open .navbar-fixed-top, .modal-open .navbar-fixed-bottom,
            .modal-open .navbar, .modal-open header, .modal-open nav,
            .modal-backdrop, .modal.in {
                padding-right: 0px !important;
                margin-right: 0px !important;
            }

            /* ★ ボタンをまとめるコンテナ：占有高さを20pxに完全ロックし、ボタン同士の横の間隔をキープ */
            .atcoder-filter-button-container {
                display: inline-flex !important;
                align-items: center !important;
                flex-wrap: nowrap !important;   /* 絶対に途中で折り返さない（元通り） */
                gap: 8px !important;            /* 横の間隔：ボタンとボタンの間の隙間を元の8pxに完全固定 */
                margin: 0 !important;           /* 外側の余白は20pxの時の設定にロック */
                padding: 0 !important;
                vertical-align: middle !important;
                height: 20px !important;        /* 行としての占有高さを元の20pxに固定 */
                line-height: 20px !important;
            }

            /* ★ ボタン自体：高さを30pxにしつつ、上下は20pxの枠内にめり込ませ、左右の間隔は元のまま維持 */
            .atcoder-filter-button-container button.filtering-by-group-btn,
            .atcoder-filter-button-container button.clear-filtering-outer-btn,
            #openGroupManagerBtn,
            .search-mode-toggle-btn {
                display: inline-flex !important;
                align-items: center !important;
                justify-content: center !important;
                height: 25px !important;        /* 高さは押しやすい30pxに拡大 */
                padding: 0 8px !important;       /* ボタン内の左右の余白（元通り） */
                line-height: 1 !important;
                vertical-align: middle !important;
                box-sizing: border-box !important;
                white-space: nowrap !important; /* ボタン内文字の改行を防止（元通り） */

                /* ↓【上下の調整】大きくなった縦幅分（5px分）を上下-2.5pxずつ削ってめり込ませる */
                margin-top: -2.5px !important;
                margin-bottom: -2.5px !important;

                /* ↓【横の間隔の調整】左右のマージンは「0」にリセットすることで、コンテナ側の gap: 8px がズレずに100%正確に適用される */
                margin-left: 0 !important;
                margin-right: 0 !important;
            }

            /* 隣接する公式リンク（お気に入り管理等がある場合）：20pxの高さに合わせて中央揃え */
            .atcoder-filter-button-container + button,
            .atcoder-filter-button-container + a,
            .atcoder-filter-button-container + .btn-text {
                margin-left: 10px !important;
            }

            .edit-group-cols { display: flex; gap: 15px; }
            .edit-group-col { flex: 1; max-height: 400px; min-height: 400px; overflow-y: auto; padding: 0; border: 1px solid #ddd; border-radius: 4px; }

            /* ★ヘッダー全体：文字のセンターを維持しつつ、省略を防ぐ */
            .edit-group-col-header {
                position: relative !important;   /* 右端ボタンの基準 */
                display: block !important;
                text-align: center !important;   /* ★文字を完全に中央揃えにする */
                background: #f5f5f5 !important;

                /* ★左右均等に 30px だけ空ける（これで中央がズレなくなります） */
                padding: 0 30px !important;

                font-weight: bold !important;
                font-size: 14px !important;
                border-bottom: 1px solid #ddd !important;
                height: 38px !important;
                line-height: 38px !important;    /* 縦方向の中央揃え */
                box-sizing: border-box !important;
                white-space: nowrap !important;

                /* 省略を絶対にさせない設定 */
                overflow: visible !important;
                text-overflow: clip !important;
            }

            /* ★以前追加した ::before が残っていた場合のエラー防止リセット */
            .edit-group-col-header::before {
                display: none !important;
                content: none !important;
            }

            /* 既存の #memberSortToggleBtn 定義を削除し、以下のクラス定義に差し替え・追加 */
            .header-sort-btn-group {
                position: absolute !important;
                right: 10px !important;
                top: 50% !important;
                transform: translateY(-50%) !important;
                display: inline-flex !important;
                gap: 4px !important;
                z-index: 10 !important;
            }

            .header-sort-btn-group button {
                height: 22px !important;
                padding: 0 6px !important;
                font-size: 11px !important;
                line-height: 20px !important;
                font-weight: normal !important;
                text-align: center !important;
                white-space: nowrap !important;
                box-sizing: border-box !important;
                margin: 0 !important;
            }

            #userReverseToggleBtn, #memberReverseToggleBtn {
                width: 24px !important;
                padding: 0 !important;
            }
            /* ★ ボタンがアクティブ（選択中）状態になっても、カーソルを離したら元の見た目と100%完全に同じにする */
            .header-sort-btn-group button.btn-default.active {
                 color: #333 !important;
                 background-color: #fff !important;
                 border-color: #ccc !important;
                 box-shadow: none !important;
                 -webkit-box-shadow: none !important;
                 outline: 0 !important;
            }

            .user-item { display: flex; align-items: center; justify-content: space-between; padding: 5px 12px; border-bottom: 1px solid #eee; min-height: 44px; }
            .user-name { font-size: 14px; font-weight: bold; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 65%; }
            .user-item.list-group-item-success { background-color: #dff0d8 !important; color: #3c763d; }

            .user-search-wrapper, .group-search-wrapper, .member-search-wrapper {
                padding: 10px;
                border-bottom: 1px solid #ddd;
                background: #fafafa;
                width: 100% !important;
                box-sizing: border-box !important;
            }
            .group-search-wrapper { border: 1px solid #ddd; border-radius: 4px; margin-bottom: 10px; padding: 6px 10px; }
            .group-search-wrapper + div { border-top: none !important; }

            .user-search-wrapper .input-group, .group-search-wrapper .input-group, .member-search-wrapper .input-group {
                display: table !important;
                table-layout: fixed !important;
                width: 100% !important;
            }

            #userSearchInput, #groupSearchInput, #memberSearchInput {
                display: table-cell !important;
                width: 100% !important;
                border-top-right-radius: 0 !important;
                border-bottom-right-radius: 0 !important;
                height: 30px !important;
                box-sizing: border-box !important;
            }

            /* ★ 幅を 80px から 110px に広げ、切り替え時のガタつき・横幅変動を完全に固定 */
            .user-search-wrapper .input-group-btn, .group-search-wrapper .input-group-btn, .member-search-wrapper .input-group-btn {
                display: table-cell !important;
                width: 60px !important;
                vertical-align: middle !important;
            }

            .input-group-btn { width: 40px !important; }

            .search-mode-toggle-btn {
                width: 100% !important;
                border-top-left-radius: 0 !important;
                border-bottom-left-radius: 0 !important;
                height: 30px !important;
                padding: 4px 0 !important;
                font-size: 12px !important;
                text-align: center !important;
                white-space: nowrap !important; /* ★ 文字数が変わっても絶対に改行させない */
                border-left: none;
            }
            .search-mode-toggle-btn.active {
                background-color: #337ab7 !important;
                color: #fff !important;
                border-color: #2e6da4 !important;
            }

            /* ★【修正】アニメーションを邪魔せず、閉じているときは絶対にクリックや表示をさせない安全設定 */
            .modal:not(.in) {
                pointer-events: none !important;
                visibility: hidden !important;
            }

            .group-row-item.dragging { opacity: 0.5; background-color: #f5f5f5; }
            .custom-group-btn { padding: 5px 10px !important; font-size: 12px !important; border-radius: 3px !important; margin-right: 5px !important; font-weight: normal !important; }
            .group-drag-handle { display: inline-block; cursor: move; padding: 5px 4px 5px 8px; color: #999; font-size: 14px; font-weight: bold; user-select: none; }
            .modal.in { overflow: hidden !important; }
            #groupFilterModal .modal-dialog, #editGroupModal .modal-dialog, #createGroupModal .modal-dialog, #renameGroupModal .modal-dialog, #customAlertModal .modal-dialog, #customConfirmModal .modal-dialog { position: fixed !important; top: 50% !important; left: 50% !important; margin: 0 !important; transform: translate(-50%, -50%) !important; }
            .modal-backdrop ~ .modal-backdrop { opacity: 0 !important; filter: alpha(opacity=0) !important; }

            #createNewGroupBtn, #innerClearFilteringBtn, #triggerImportJsonBtn, #exportJsonBtn { font-weight: normal !important; }

            /* ★ 追加中のユーザーの右側ボタンを「危険色（削除ボタンの見た目）」に動的変化させる設定 */
            .user-item.list-group-item-success button {
                background-color: #d9534f !important;
                border-color: #d43f3a !important;
                color: #fff !important;
            }
            .user-item.list-group-item-success button:hover {
                background-color: #c9302c !important;
                border-color: #ac2925 !important;
                color: #fff !important;
            }
        `);
    }

    function createIntegratedModal() {
        if (document.getElementById('groupFilterModal')) return;
        const modal = document.createElement('div'); modal.className = 'modal fade'; modal.id = 'groupFilterModal'; modal.setAttribute('tabindex', '-1'); modal.setAttribute('role', 'dialog');
        modal.innerHTML = `
            <div class="modal-dialog" role="document" style="width: 95%; max-width: 650px;">
                <div class="modal-content">
                    <div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button><h4 class="modal-title">フィルター管理</h4></div>
                    <div class="modal-body" style="padding-bottom: 10px;">
                        <div class="container-fluid">
                            <div class="row" style="margin-bottom: 10px;">
                                <div class="col-xs-12">
                                    <div class="checkbox" style="margin: 0; padding: 8px 10px; background: #fafafa; border: 1px solid #eee; border-radius: 4px;">
                                        <label for="noneFilter" style="font-weight: bold; display: block; font-size: 13px; cursor: pointer;">
                                            <input type="checkbox" id="noneFilter" style="width:15px; height:15px; vertical-align:middle; margin-top:0;"> すべてのお気に入り
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-12">
                                    <div class="group-search-wrapper">
                                        <div class="input-group">
                                            <input type="text" class="form-control input-sm" id="groupSearchInput" placeholder="グループ名を検索...">
                                            <span class="input-group-btn">
                                                <button type="button" class="btn btn-default btn-sm search-mode-toggle-btn" id="groupSearchModeToggleBtn">前方一致</button>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="max-height: 320px; min-height: 320px; overflow-y: auto; border: 1px solid #ddd; border-radius: 4px; margin: 0 0 15px 0;"><table class="table table-hover" style="margin-bottom: 0;"><tbody id="groupFilterTableBody"></tbody></table></div>

                            <div class="row" style="display: flex; align-items: center; justify-content: space-between;">
                                <div class="col-xs-8" style="padding-top: 5px; padding-left: 15px; display: inline-flex; align-items: center; justify-content: flex-start; gap: 18px; flex-wrap: nowrap;">

                                    <div style="display: inline-flex; align-items: center; gap: 10px;">
                                        <label style="font-size:13px; margin: 0; padding: 0; display: inline-flex; align-items: center; gap: 4px; cursor: pointer; font-weight: normal;">
                                            <input type="radio" name="operation" value="OR" style="margin: 0; position: static; vertical-align: middle;"><strong>OR</strong>
                                        </label>
                                        <label style="font-size:13px; margin: 0; padding: 0; display: inline-flex; align-items: center; gap: 4px; cursor: pointer; font-weight: normal;">
                                            <input type="radio" name="operation" value="AND" style="margin: 0; position: static; vertical-align: middle;"><strong>AND</strong>
                                        </label>
                                    </div>

                                    <div style="display: inline-flex; align-items: center;">
                                        <label for="modal-checkbox-hide-absent" style="font-size: 12px; font-weight: bold; cursor: pointer; display: inline-flex; align-items: center; gap: 4px; margin: 0; padding: 0; white-space: nowrap;">
                                            <input type="checkbox" id="modal-checkbox-hide-absent" style="width:14px; height:14px; margin: 0; position: static; vertical-align: middle;"> お気に入りの不参加者を非表示
                                        </label>
                                    </div>

                                </div>

                                <div class="col-xs-4 text-right">
                                    <button type="button" class="btn btn-default btn-sm" id="createNewGroupBtn">＋ 新規グループ作成</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 5px;">
                        <div style="display: inline-flex; gap: 5px; align-items: center;"><button type="button" class="btn btn-default" id="triggerImportJsonBtn" style="width: 120px;">JSON読み込み</button><button type="button" class="btn btn-default" id="exportJsonBtn" style="width: 120px;">JSON書き出し</button><input type="file" id="importJsonInput" accept=".json" style="display: none;"></div>
                        <div style="display: inline-flex; gap: 5px;"><button type="button" class="btn btn-danger btn-sm" id="innerClearFilteringBtn">フィルター解除</button><button type="button" class="btn btn-default" data-dismiss="modal" style="width: 80px;">閉じる</button></div>
                    </div>
                </div>
            </div>
        `;
    document.body.appendChild(modal);

    const outerHideAbsent = document.getElementById("checkbox-hide-absent") ||
          document.querySelector("input[id*='hide-absent']");
    const modalHideAbsent = document.getElementById("modal-checkbox-hide-absent");

    // 双方向リアルタイム同期イベント（Vueの読み込み状態に応じて安全に分岐）
    if (modalHideAbsent) {
        modalHideAbsent.addEventListener('change', () => {
            const state = getFilterState();
            state.hideAbsent = modalHideAbsent.checked;
            saveFilterState(state);

            if (typeof getVueInstance === 'function' && getVueInstance()) {
                syncVueFavSet();
            }
        });

        if (outerHideAbsent) {
            outerHideAbsent.addEventListener('change', () => {
                const state = getFilterState();
                modalHideAbsent.checked = !!state.hideAbsent;

                if (typeof getVueInstance === 'function' && getVueInstance()) {
                    syncVueFavSet();
                }
            });
        }
    }

    document.getElementById('createNewGroupBtn').addEventListener('click', openCreateGroupModal);
    document.getElementById('innerClearFilteringBtn').addEventListener('click', (e) => { e.preventDefault(); clearFiltering(); });
    document.getElementById('exportJsonBtn').addEventListener('click', (e) => { e.preventDefault(); exportFilterDataAsJSON(); });
    const importInput = document.getElementById('importJsonInput');
    document.getElementById('triggerImportJsonBtn').addEventListener('click', (e) => { e.preventDefault(); importInput.click(); });
    importInput.addEventListener('change', importFilterDataFromJSON);

    modal.querySelectorAll('input[name="operation"]').forEach(r => r.addEventListener('change', () => {
        if (typeof getVueInstance === 'function' && getVueInstance()) {
            saveGroupFilterModalStateAuto();
            syncVueFavSet();
        } else {
            const state = getFilterState();
            state.operation = r.value;
            saveFilterState(state);
        }
    }));

    // ★【完全解決：最終確定ロック】
    // 外部の初期描画関数（updateModalContent等）がこの関数の直後に実行されても
    // 見た目が崩れないよう、関数の最末尾でもう一度ストレージの値を強制バインドします。
    const finalState = getFilterState();
    if (modalHideAbsent) {
        modalHideAbsent.checked = !!finalState.hideAbsent;
    }
    const finalOp = finalState.operation || 'OR';
    const finalRadio = modal.querySelector(`input[name="operation"][value="${finalOp}"]`);
    if (finalRadio) {
        finalRadio.checked = true;
    }
}

    function createEditGroupModal() {
        if (document.getElementById('editGroupModal')) return;
        const modal = document.createElement('div'); modal.className = 'modal fade'; modal.id = 'editGroupModal'; modal.setAttribute('tabindex', '-1'); modal.setAttribute('role', 'dialog');
        // createEditGroupModal 関数内の innerHTML 部分を以下に差し替え
        // （お気に入りユーザー側にもボタンのコンテナを配置し、それぞれに逆順ボタンを追加）
        modal.innerHTML = `
        <div class="modal-dialog" role="document" style="width: 90%; max-width: 800px;">
            <div class="modal-content">
                <div class="modal-header"><button type="button" class="close" id="editGroupModalCloseX"><span aria-hidden="true">×</span></button><h4 class="modal-title" id="editGroupHeader">メンバー編集</h4></div>
                <div class="modal-body">
                    <div class="container-fluid">
                        <div class="edit-group-cols">
                            <div class="edit-group-col panel panel-default">
                                <div class="edit-group-col-header">
                                    <span>お気に入りユーザー</span>
                                    <div class="header-sort-btn-group">
                                        <button type="button" class="btn btn-default btn-xs" id="userSortToggleBtn">ABC順</button>
                                        <button type="button" class="btn btn-default btn-xs" id="userReverseToggleBtn">▲</button>
                                    </div>
                                </div>
                                <div class="user-search-wrapper">
                                    <div class="input-group">
                                        <input type="text" class="form-control input-sm" id="userSearchInput" placeholder="ユーザー名を検索...">
                                        <span class="input-group-btn">
                                            <button type="button" class="btn btn-default btn-sm search-mode-toggle-btn" id="userSearchModeToggleBtn">前方一致</button>
                                        </span>
                                    </div>
                                </div>
                                <div class="list-group" id="favoriteUsersList" style="margin-bottom:0;"></div>
                            </div>
                            <div class="edit-group-col panel panel-default">
                                <div class="edit-group-col-header">
                                    <span>グループ所属メンバー</span>
                                    <div class="header-sort-btn-group">
                                        <button type="button" class="btn btn-default btn-xs" id="memberSortToggleBtn">登録順</button>
                                        <button type="button" class="btn btn-default btn-xs" id="memberReverseToggleBtn">▲</button>
                                    </div>
                                </div>
                                <div class="member-search-wrapper">
                                    <div class="input-group">
                                        <input type="text" class="form-control input-sm" id="memberSearchInput" placeholder="所属メンバーを検索...">
                                        <span class="input-group-btn">
                                            <button type="button" class="btn btn-default btn-sm search-mode-toggle-btn" id="memberSearchModeToggleBtn">前方一致</button>
                                        </span>
                                    </div>
                                </div>
                                <div class="list-group" id="groupMembersList" style="margin-bottom:0;"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer"><button type="button" class="btn btn-primary" id="editGroupModalSaveBtn" style="width: 100px;">保存</button><button type="button" class="btn btn-default" id="editGroupModalCancelBtn">キャンセル</button></div>
            </div>
        </div>
    `;
        document.body.appendChild(modal);
        document.getElementById('editGroupModalSaveBtn').addEventListener('click', (e) => { e.preventDefault(); saveEditGroupMembers(); });
        document.getElementById('editGroupModalCancelBtn').addEventListener('click', (e) => { e.preventDefault(); checkEditGroupModalCancel(); });
        document.getElementById('editGroupModalCloseX').addEventListener('click', (e) => { e.preventDefault(); checkEditGroupModalCancel(); });
    }

    function createNewGroupModal() { if (document.getElementById('createGroupModal')) return; const modal = document.createElement('div'); modal.className = 'modal fade'; modal.id = 'createGroupModal'; modal.setAttribute('tabindex', '-1'); modal.setAttribute('role', 'dialog'); modal.innerHTML = `<div class="modal-dialog" role="document" style="width: 90%; max-width: 400px;"><div class="modal-content"><div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button><h4 class="modal-title">新規グループ作成</h4></div><div class="modal-body"><div class="container-fluid"><label for="newGroupNameInput" style="font-weight: bold;">グループ名を入力してください</label><input type="text" class="form-control" id="newGroupNameInput" placeholder="グループ名"></div></div><div class="modal-footer"><button type="button" class="btn btn-primary btn-block" id="createGroupModalOkBtn">作成</button></div></div></div>`; document.body.appendChild(modal); document.getElementById('createGroupModalOkBtn').addEventListener('click', confirmCreateGroup); }
    function createRenameGroupModal() { if (document.getElementById('renameGroupModal')) return; const modal = document.createElement('div'); modal.className = 'modal fade'; modal.id = 'renameGroupModal'; modal.setAttribute('tabindex', '-1'); modal.setAttribute('role', 'dialog'); modal.innerHTML = `<div class="modal-dialog" role="document" style="width: 90%; max-width: 400px;"><div class="modal-content"><div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button><h4 class="modal-title">グループ名の変更</h4></div><div class="modal-body"><div class="container-fluid"><label for="renameGroupNameInput" style="font-weight: bold;">新しいグループ名</label><input type="text" class="form-control" id="renameGroupNameInput" placeholder="グループ名"></div></div><div class="modal-footer"><button type="button" class="btn btn-primary btn-block" id="renameGroupModalOkBtn">変更を確定</button></div></div></div>`; document.body.appendChild(modal); document.getElementById('renameGroupModalOkBtn').addEventListener('click', confirmRenameGroup); }
    function createNotificationModals() { if (!document.getElementById('customAlertModal')) { const alertModal = document.createElement('div'); alertModal.className = 'modal fade'; alertModal.id = 'customAlertModal'; alertModal.setAttribute('tabindex', '-1'); alertModal.setAttribute('role', 'dialog'); alertModal.innerHTML = `<div class="modal-dialog" role="document" style="width: 90%; max-width: 420px; z-index: 2050;"><div class="modal-content"><div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button><h4 class="modal-title" id="customAlertTitle">通知</h4></div><div class="modal-body"><p id="customAlertBody" style="font-size: 14px; margin: 10px 0; word-break: break-all;"></p></div><div class="modal-footer"><button type="button" class="btn btn-primary" data-dismiss="modal" style="width: 80px;">OK</button></div></div></div>`; document.body.appendChild(alertModal); } if (!document.getElementById('customConfirmModal')) { const confirmModal = document.createElement('div'); confirmModal.className = 'modal fade'; confirmModal.id = 'customConfirmModal'; confirmModal.setAttribute('tabindex', '-1'); confirmModal.setAttribute('role', 'dialog'); confirmModal.innerHTML = `<div class="modal-dialog" role="document" style="width: 90%; max-width: 420px; z-index: 2050;"><div class="modal-content"><div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button><h4 class="modal-title" id="customConfirmTitle">確認</h4></div><div class="modal-body"><p id="customConfirmBody" style="font-size: 14px; margin: 10px 0; word-break: break-all;"></p></div><div class="modal-footer"><button type="button" class="btn btn-danger" id="customConfirmOkBtn" style="width: 80px;">はい</button><button type="button" class="btn btn-default" data-dismiss="modal" style="width: 80px;">いいえ</button></div></div></div>`; document.body.appendChild(confirmModal); } }

    function addHeaderMenuLink() {
        if (document.querySelector('.header-filter-management-li')) return;

        const createItemHtml = (iconClass) => {
            return `<a href="#" class="headerFilterManagementBtn-trigger"><span class="${iconClass}" aria-hidden="true"></span> フィルター管理</a>`;
        };

        const injectTab = () => {
            const currentTab = document.querySelector('.header-filter-management-li');

            const favTarget = Array.from(document.querySelectorAll('.header-mypage_list li, .navbar-right .dropdown-menu li'))
            .find(li => {
                const a = li.querySelector('a');
                return a && (a.textContent.includes('お気に入り管理') || a.getAttribute('href')?.includes('/settings/fav'));
            });

            if (favTarget) {
                if (currentTab) {
                    if (currentTab.previousElementSibling !== favTarget) {
                        currentTab.remove();
                        favTarget.insertAdjacentElement("afterend", currentTab);
                    }
                } else {
                    const newLi = document.createElement('li');
                    newLi.className = 'header-filter-management-li';
                    const isNewLayout = favTarget.closest('.header-mypage_list') !== null;
                    newLi.innerHTML = createItemHtml(isNewLayout ? 'a-icon a-icon-star' : 'glyphicon glyphicon-star');
                    favTarget.insertAdjacentElement("afterend", newLi);
                    bindClickEvent(newLi.querySelector('.headerFilterManagementBtn-trigger'));
                }
            } else {
                if (currentTab) return;
                const newDropdownTarget = document.querySelector(".header-mypage_list li:nth-last-child(1)");
                if (newDropdownTarget) {
                    const newLi = document.createElement('li'); newLi.className = 'header-filter-management-li'; newLi.innerHTML = createItemHtml('a-icon a-icon-filter'); newDropdownTarget.insertAdjacentElement("beforebegin", newLi);
                    bindClickEvent(newLi.querySelector('.headerFilterManagementBtn-trigger'));
                }
            }
        };

        const bindClickEvent = (el) => {
            if (!el) return;
            el.addEventListener('click', e => {
                e.preventDefault();
                openBootstrapModal('groupFilterModal', () => {
                    setupGroupSearchModeToggle();
                    updateModalContent();
                    updateClearButtonState();
                });
            });
        };

        injectTab();

        const headerNav = document.querySelector('.header-mypage_list') || document.querySelector('.navbar-right .dropdown-menu');
        if (headerNav) {
            const observer = new MutationObserver(() => {
                injectTab();
            });
            observer.observe(headerNav, { childList: true, subtree: true });
        }
    }

    // ★ お気に入り管理ページにフィルター管理ボタンを追加する関数（ボタン構造に合わせた最適化版）
    function addFavPageFilteringButton() {
        if (!window.location.href.includes('/settings/fav')) return;
        if (document.getElementById('favPageFilterManagementBtn')) return;

        // 提示された「同期」ボタン（glyphicon-transferを持つ要素の親ボタン、またはaタグ）を探す
        let syncBtn = document.querySelector('.glyphicon-transfer')?.closest('a, button');

        // 見つからない場合のフォールバック（既存の送信ボタンなど）
        if (!syncBtn) {
            syncBtn = document.querySelector('button.btn-primary[type="submit"]') || document.querySelector('.form-group button, .form-group a');
        }

        if (!syncBtn) return;

        // ボタンを配置するコンテナ
        const container = syncBtn.parentElement;
        if (!container) return;

        // フィルター管理を開くボタンを作成
        const favPageBtn = document.createElement('a'); // 同期ボタンに合わせてaタグで作成
        favPageBtn.href = '#';
        favPageBtn.id = 'favPageFilterManagementBtn';
        favPageBtn.className = 'btn btn-default';
        favPageBtn.style.marginLeft = '10px'; // 同期ボタンとの間隔
        favPageBtn.style.verticalAlign = 'middle';
        favPageBtn.innerHTML = '<span class="glyphicon glyphicon-filter" aria-hidden="true" style="margin-right: 5px;"></span>フィルター管理';

        // クリック時にフィルター管理モーダルを開く
        favPageBtn.addEventListener('click', (e) => {
            e.preventDefault();
            openBootstrapModal('groupFilterModal', () => {
                setupGroupSearchModeToggle();
                updateModalContent();
                updateClearButtonState();
            });
        });

        // 「同期」ボタンの直後に挿入
        syncBtn.insertAdjacentElement('afterend', favPageBtn);
    }

    function addCommonFilteringButtons() {
        if (document.querySelector('.filtering-by-group-btn')) return;

        const vm = getVueInstance();
        if (!vm) return;

        const hasData = vm.standings || vm.results || (vm.filteredStandings && typeof vm.filteredStandings === 'object');
        if (!hasData) return;

        let favCheckbox = document.getElementById("checkbox-fav-only");
        let parentContainer = null;

        if (!favCheckbox) {
            return;
        } else {
            parentContainer = favCheckbox.closest('label') || favCheckbox.parentElement;
        }

        // ==========================================
        // ★ ここから要素の構造変更とクラス付与の処理
        // ==========================================

        // 1. 元の親（「お気に入りのみ表示」の div.checkbox）を取得してクラスを付与
        const favCheckboxRow = parentContainer.parentNode && parentContainer.parentNode.classList.contains('checkbox')
        ? parentContainer.parentNode
        : parentContainer.closest('.checkbox');

        // 2. ボタンだけをまとめるコンテナ（wrapper）を作成
        const wrapper = document.createElement('div');
        wrapper.className = 'atcoder-filter-button-container';

        // 3. 不参加者非表示用の「新しい div class="checkbox"」と「label」を作成
        const filterState = getFilterState();

        const hideAbsentLabel = document.createElement('label');
        hideAbsentLabel.className = 'hide-absent-checkbox-label';
        // ★ disabled状態でもラベル部分をクリックして操作できるようにCSSで微調整
        hideAbsentLabel.style.cursor = 'pointer';
        hideAbsentLabel.innerHTML = `<input type="checkbox" id="checkbox-hide-absent" ${filterState.hideAbsent ? 'checked' : ''}> お気に入りの不参加者を非表示`;
        const hideAbsentCheckbox = hideAbsentLabel.querySelector('input');

        let hideAbsentCheckboxRow = null;
        const currentUrl = window.location.href;
        if (currentUrl.includes('/standings')) {
            hideAbsentCheckboxRow = document.createElement('div');
            hideAbsentCheckboxRow.className = 'checkbox atcoder-filter-checkbox-row';
            hideAbsentCheckboxRow.appendChild(hideAbsentLabel);
        }

        // 4. 各ボタンの作成
        const filteringBtn = document.createElement('button');
        filteringBtn.textContent = 'フィルター管理';
        filteringBtn.className = 'btn btn-default btn-sm filtering-by-group-btn';
        filteringBtn.id = 'outerFilterManagementBtn';
        filteringBtn.type = 'button';
        filteringBtn.addEventListener('click', e => {
            e.preventDefault(); e.stopPropagation();
            openBootstrapModal('groupFilterModal', () => {
                setupGroupSearchModeToggle();
                updateModalContent();
                updateClearButtonState();
            });
        });

        const outerClearBtn = document.createElement('button');
        outerClearBtn.textContent = 'フィルター解除';
        outerClearBtn.className = 'btn btn-danger btn-sm clear-filtering-outer-btn';
        outerClearBtn.id = 'outerClearFilteringBtn';
        outerClearBtn.type = 'button';
        outerClearBtn.addEventListener('click', e => {
            e.preventDefault(); e.stopPropagation();
            clearFiltering();
        });

        // 5. ボタン類を wrapper に追加
        wrapper.appendChild(filteringBtn);
        wrapper.appendChild(outerClearBtn);

        // 6. 【配置】すべてを独立した兄弟要素として順番に並べる
        if (favCheckboxRow) {
            let lastElement = favCheckboxRow;

            // 順位表ページなら、次に不参加者の div.checkbox を挿入
            if (hideAbsentCheckboxRow) {
                lastElement.insertAdjacentElement('afterend', hideAbsentCheckboxRow);
                lastElement = hideAbsentCheckboxRow;
            }
            // 最後にボタンのコンテナを挿入
            lastElement.insertAdjacentElement('afterend', wrapper);
        }

        // ==========================================
        // ★ イベントリスナーと初期化処理
        // ==========================================
        favCheckbox.addEventListener('change', function() {
            if (isSyncing) return;
            const currentVm = getVueInstance();
            if (currentVm) {
                if ('favOnly' in currentVm) currentVm.favOnly = favCheckbox.checked;
                if ('favsOnly' in currentVm) currentVm.favsOnly = favCheckbox.checked;
                updateExtensionUIState(favCheckbox.checked);
                setTimeout(syncVueFavSet, 10);
            } else {
                updateExtensionUIState(favCheckbox.checked);
            }
        });

        // ★【修正】disabled のガードを除去し、お気に入りオフでも確実に同期・反映するイベントに変更
        hideAbsentCheckbox.addEventListener('change', function() {
            const state = getFilterState();
            state.hideAbsent = this.checked;

            // 1. 裏側のストレージへ保存
            saveFilterState(state);

            // 2. モーダル内のチェックボックスが開いていれば見た目を同期
            const modalHideAbsent = document.getElementById("modal-checkbox-hide-absent");
            if (modalHideAbsent) {
                modalHideAbsent.checked = this.checked;
            }

            // 3. Vueと順位表に強制通知・再描画
            syncVueFavSet();
        });

        updateExtensionUIState(favCheckbox.checked);
        updateClearButtonState();
    }

    function patchBootstrapModalEnforceFocus() {
        if (viewWindow.$ && typeof viewWindow.$ === 'function') {
            const cleanBootstrapStyles = () => {
                if (document.body) {
                    document.body.style.removeProperty('padding-right');
                    document.body.style.removeProperty('overflow');
                }
                const fixedElements = document.querySelectorAll('.navbar-fixed-top, .navbar-fixed-bottom, .navbar, header, nav, #header');
                fixedElements.forEach(el => {
                    el.style.removeProperty('padding-right');
                });
            };

            viewWindow.$(document).on('show.bs.modal loaded.bs.modal shown.bs.modal hide.bs.modal hidden.bs.modal', '.modal', function () {
                cleanBootstrapStyles();
                if (viewWindow.$('.modal.in').length > 0) {
                    viewWindow.$('body').addClass('modal-open');
                }
            });
        }
    }

    function initializeUI() {
        try {
            addExtensionStyles();
            createIntegratedModal();
            createEditGroupModal();
            createNewGroupModal();
            createRenameGroupModal();
            createNotificationModals();
            patchBootstrapModalEnforceFocus();
            addHeaderMenuLink();
            addFavPageFilteringButton();

            const currentUrl = window.location.href;
            if (currentUrl.includes('/contests/') && (currentUrl.includes('/standings') || currentUrl.includes('/results'))) {
                let attempts = 0;
                const checkTimer = setInterval(() => {
                    attempts++;
                    const vm = getVueInstance();
                    // 初期化時（またはhijack時）に元の状態を一度だけ保存しておく
                    if (vm && !vm._originalFavSet) {
                        vm._originalFavSet = new Set(vm.favSet);
                    }

                    if (vm && attempts > 10) {
                        const hasValidData = vm.standings || vm.results;
                        if (!hasValidData) {
                            clearInterval(checkTimer);
                            const activeContainer = document.querySelector('.atcoder-filter-button-container');
                            if (activeContainer) {
                                const originalFav = document.getElementById("checkbox-fav-only");
                                if (originalFav) {
                                    const origLabel = originalFav.closest('label') || originalFav.parentElement;
                                    activeContainer.parentNode.insertBefore(origLabel, activeContainer);
                                }
                                activeContainer.remove();
                            }
                            return;
                        }
                    }

                    if (vm && (vm.standings || vm.results)) {
                        clearInterval(checkTimer);
                        addCommonFilteringButtons();
                        syncVueFavSet();
                    }
                }, 150);
                setTimeout(() => clearInterval(checkTimer), 6000);
            }
        } catch (uiError) {
            console.error("[AtCoder Favorite Group Manager] UI構築中のエラー:", uiError);
        }
    }

    initializeGroups();
    if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', initializeUI); }
    else { initializeUI(); }
})();